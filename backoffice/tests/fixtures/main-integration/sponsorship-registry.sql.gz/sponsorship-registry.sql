BEGIN TRANSACTION;
CREATE TABLE bindings (
    repository TEXT NOT NULL, issue INTEGER NOT NULL, upstream TEXT NOT NULL, fork TEXT NOT NULL,
    config_sha TEXT NOT NULL, PRIMARY KEY (repository, issue));
CREATE TABLE credential_cursor (id INTEGER PRIMARY KEY,sequence INTEGER NOT NULL);
CREATE TABLE credential_versions (
    user_id TEXT NOT NULL,route TEXT NOT NULL,sequence INTEGER NOT NULL,document TEXT NOT NULL,
    PRIMARY KEY(user_id,route));
CREATE TABLE deferred (repository TEXT NOT NULL, issue INTEGER NOT NULL, snapshot TEXT NOT NULL,
                       PRIMARY KEY (repository, issue));
CREATE TABLE deliveries (id TEXT PRIMARY KEY, received REAL NOT NULL);
CREATE TABLE funding_policies (
    sequence INTEGER PRIMARY KEY AUTOINCREMENT, repository TEXT NOT NULL,
    started REAL NOT NULL, ended REAL, receipt TEXT NOT NULL);
INSERT INTO "funding_policies" VALUES(1,'cylewitruk/stacks-core-autobot',1000000.0,NULL,'{"repository": "cylewitruk/stacks-core-autobot", "config_digest": "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd", "funding_mode": "contributed", "effective_from": 1000000.0, "previous": null, "receipt_id": "aee4c4118bc48a8b894df86550b0af1da0b6b897e37b45cce2fb28c7f948a809"}');
CREATE TABLE issue_sponsor_sources (
    repository TEXT NOT NULL, issue INTEGER NOT NULL, revision TEXT NOT NULL, source TEXT NOT NULL,
    PRIMARY KEY(repository,issue,revision));
CREATE TABLE issue_sponsorships (
    repository TEXT NOT NULL, issue INTEGER NOT NULL, source_revision INTEGER NOT NULL,
    confirmed INTEGER NOT NULL, document TEXT, PRIMARY KEY(repository,issue));
INSERT INTO "issue_sponsorships" VALUES('cylewitruk/stacks-core-autobot',7,0,1,'{"facts": [{"actor_id": "202", "command": "sponsor", "grant_id": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "provider": "openai"}], "revision": "parent-source", "slots": {"openai": {"epoch": 3, "sponsor_id": "202"}}, "status": "confirmed"}');
CREATE TABLE meta (name TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO "meta" VALUES('registry_id','registry-test');
INSERT INTO "meta" VALUES('schema','8');
CREATE TABLE mutations (intent TEXT PRIMARY KEY, repository TEXT NOT NULL, issue INTEGER NOT NULL,
                        generation INTEGER NOT NULL, sequence INTEGER NOT NULL, method TEXT NOT NULL,
                        path TEXT NOT NULL, digest TEXT NOT NULL, status TEXT NOT NULL, admitted REAL NOT NULL,
                        settled REAL, resolution TEXT, UNIQUE (repository, issue, generation, sequence));
CREATE TABLE observations (
    repository TEXT NOT NULL, issue INTEGER NOT NULL, version INTEGER NOT NULL,
    due_at REAL NOT NULL, attempts INTEGER NOT NULL, expectations TEXT NOT NULL, PRIMARY KEY (repository, issue));
CREATE TABLE outcomes (repository TEXT NOT NULL, issue INTEGER NOT NULL, kind TEXT NOT NULL,
                       progressed INTEGER NOT NULL, retry_after INTEGER, recorded REAL NOT NULL,
                       PRIMARY KEY (repository, issue));
CREATE TABLE ownership (repository TEXT NOT NULL, issue INTEGER NOT NULL, generation INTEGER NOT NULL,
                        worker TEXT NOT NULL, lease_until REAL NOT NULL, live INTEGER NOT NULL,
                        PRIMARY KEY (repository, issue));
CREATE TABLE pulls (repository TEXT NOT NULL, issue INTEGER NOT NULL,
                    pull_repository TEXT NOT NULL, pull INTEGER NOT NULL,
                    PRIMARY KEY (repository, issue), UNIQUE (pull_repository, pull));
CREATE TABLE queue (repository TEXT NOT NULL, issue INTEGER NOT NULL, causes TEXT NOT NULL,
                    due_at REAL NOT NULL, PRIMARY KEY (repository, issue));
INSERT INTO "queue" VALUES('cylewitruk/stacks-core-autobot',7,'["parent-fixture"]',2000.0);
CREATE TABLE review_intents (intent TEXT PRIMARY KEY, context TEXT NOT NULL, recovery TEXT);
CREATE TABLE runner_sessions (
    id TEXT PRIMARY KEY, repository TEXT NOT NULL, issue INTEGER NOT NULL, generation INTEGER NOT NULL,
    config_sha TEXT NOT NULL, removed INTEGER NOT NULL DEFAULT 0);
CREATE TABLE snapshots (repository TEXT NOT NULL, issue INTEGER NOT NULL, snapshot TEXT NOT NULL,
                        PRIMARY KEY (repository, issue));
CREATE TABLE webhook_recovery (scope TEXT PRIMARY KEY, checked REAL NOT NULL);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('funding_policies',1);
COMMIT;
